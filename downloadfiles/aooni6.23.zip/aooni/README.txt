青鬼
ver.6.23
操作

移動　　　　　　　　　　　矢印キー、２・４・６・８
キャンセル、メニュー表示　X, Esc, 0
決定、調べる　　　　　　　C, Enter, Space
全画面　　　　　　　　　　Alt+Enter
強制終了　　　　　　　　　Alt+F4
タイトル　　　　　　　　　F12
プロパティ　　　　　　　　F1

このゲームをプレイするにはRPGツクールXP-RTPが必要です
↓からダウンロードできます
http://www.famitsu.com/freegame/rtp/xp_rtp.html

～攻略のヒント～

・敵が出現しているときは
　アイテムを取得できません。
　メニュー画面を開けません。
　鍵は開けられます。
・敵は、一定時間逃げ続けるか、タンスに身を隠すことで、
　撒くことができます。

素材提供

スクリプト

スクリプトシェルフ http://scriptshelf.jpn.org/x/
Simp http://simp.u-abel.net
歯車の城　http://members.jcom.home.ne.jp/cogwheel/
Zenith Creation http://zenith.ifdef.jp/

画像

UD COBO http://umidoriya.tyanoyu.net/cb.html
Mutation Genes Simulation T.D.Lab. http://mgshellc.lix.jp/
エトリエ http://www5f.biglobe.ne.jp/~itazu/etolier/
睡枇 尼多羅 http://amatara.turigane.com/
ツクールでいこう！ http://www1.dnet.gr.jp/~mi-ku/newpage2.htm
森の奥の隠れ里 http://fayforest.sakura.ne.jp/
ナラムラ作戦 http://naramura.sakura.ne.jp/

音

WEB WAVE LIB http://www.s-t-t.com/wwl/
ザ・マッチメイカァズ2nd http://osabisi.sakura.ne.jp/m2/

素材の二次利用を禁じます。

最終更新日2012/3/25

ゲーム置き場：http://mygames888.info/
ブログ「日記」：http://mynikki.info/
連絡先：nopropsneeded@gmail.com
